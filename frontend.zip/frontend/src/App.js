import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [peers, setPeers] = useState([]);
  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [remoteFiles, setRemoteFiles] = useState({}); // To store files per peer
  const API = "http://localhost:5000";

  const fetchData = async () => {
    try {
      const pRes = await axios.get(`${API}/peers`);
      setPeers(pRes.data);
      const fRes = await axios.get(`${API}/my-files`);
      setFiles(fRes.data);
    } catch (err) { console.error("Server not running"); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleUpload = async () => {
    if (!selectedFile) return;
    const formData = new FormData();
    formData.append("file", selectedFile);
    await axios.post(`${API}/upload`, formData);
    fetchData();
    alert("File shared locally!");
  };

  const downloadFromPeer = (peerIp, filename) => {
    // DIRECT P2P DOWNLOAD: Bypasses any central server
    window.open(`http://${peerIp}:5000/download/${filename}`, '_blank');
  };

  return (
    <div className="container">
      <h1>🎓 Student P2P Sharing</h1>
      
      <div className="card">
        <h3>📤 Your Shared Files</h3>
        <input type="file" onChange={(e) => setSelectedFile(e.target.files[0])} />
        <button onClick={handleUpload}>Upload to My Node</button>
        <ul>
          {files.map(f => <li key={f}>📄 {f}</li>)}
        </ul>
      </div>

      <div className="card">
        <h3>🌐 Available Peers (Direct Connect)</h3>
        <button onClick={fetchData}>Refresh Network</button>
        {peers.length === 0 && <p>Searching for peers...</p>}
        {peers.map(ip => (
          <div key={ip} className="peer-item">
            <span>📍 Peer: {ip}</span>
            {/* For the demo, we assume "test.txt" exists on the peer */}
            <button onClick={() => downloadFromPeer(ip, "test.txt")}>Download test.txt</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;